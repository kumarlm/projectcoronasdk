-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local widget =require "widget"
local composer = require "composer" 
local kidoz = require( "plugin.kidoz" )
local press = false
local function handlebtnevent(event)
 
  if ("ended" == event.phase)and(press == true) then
        
        print("entered")
        
         -- Show the add
        kidoz.show( "interstitial" )
		
		
		local function call()
		    composer.gotoScene("scene1")
		end
		  
         	  
		timer.performWithDelay(100,call)
		
       
		
    
	
    
    -- Initialize the KIDOZ plugin
    
 
    -- Sometime later, hide the panel view
    kidoz.hide( "interstitial" )
	
    
  end
end
local function adListener( event )
 
        if ( event.phase == "init" ) then  -- Successful initialization
         print( event.provider )
         -- Load a KIDOZ panel view ad
		 local title = display.newText( "loading", display.contentCenterX, 125, native.systemFont, 24 )
	      title:setFillColor( 1 )

         kidoz.load( "interstitial" )
 
        elseif ( event.phase == "loaded" ) then  -- The ad was successfully loaded
         print( event.type )
		 press=true
		 
		 
		 local myButton = widget.newButton
          {
          left=75,
          top=200,
          width=150,
		  height=50,
          defaultFile="before.png",
          overFile="imgg2.png",
          label="new Button",

          onEvent = handlebtnevent,
          }  
		end
end		
local img=display.newImage("down.png") 
img:translate(450,450)
 -- Initialize the KIDOZ plugin
kidoz.init( adListener, { publisherID="14183", securityToken="oLUIB5ed54SKD2GXVt8amIJ4lndFmDmV" } )
 